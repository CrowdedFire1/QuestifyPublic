package Gui;
public class SubQuest {
    private boolean complete;
    private int value;
    private int max;
    private String description;

    public SubQuest(String description, int max){
        this.complete = false;
        this.value = 0;
        this.max = max;
        this.description = description;
    }

    public SubQuest(String description, int max, int value){
        this.complete = false;
        this.value = 0;
        this.max = max;
        this.value = value;
        this.description = description;
    }

    public String getDesc(){
        return description;
    }

    public int getMax(){
        return max;
    }

    public int getVal(){
        return value;
    }

    public boolean isComplete(){
        return complete;
    }

    public void complete(){
        this.complete = true;
    }

    public void incrementValue(){
        this.value += 1;
    }

    public String getString(){
        String list = "";
        String tilda = "~";
        list = list + description + tilda + max + tilda + value;
        return list;

    }
}
