package Gui;
import java.util.ArrayList;
import java.util.List;


public class Quest {
    private List<SubQuest> subQuests;
    private boolean complete;
    private String title;
    private String description;

    public Quest(List<SubQuest> sqs, String title, String desc){
        complete = false;
        this.title = title;
        this.description = desc;
        this.subQuests = new ArrayList<>();
        for (SubQuest sq : sqs){
            this.subQuests.add(sq);
        }
    }

    public boolean isComplete(){
        return complete;
    }

    public void complete(){
        this.complete = true;
    }

    public List<SubQuest> getSubQuests(){
        return subQuests;
    }

    public String getTitle(){
        return title;
    }

    public String getDesc(){
        return description;
    }

    public SubQuest findSubQuest(int index){
        return subQuests.get(index);
    }


    public String getString(){
        String list = "";
        String comma = ",";
        list = list + title + comma + description + comma;
        for (SubQuest itm : subQuests){
            list = list + itm.getString();
        }
        return list;
    }
    
}
