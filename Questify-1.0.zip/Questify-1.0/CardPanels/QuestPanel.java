package CardPanels;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.awt.font.TextAttribute;

import Gui.Quest;
import Gui.QuestGui;
import Gui.SubQuest;

public class QuestPanel extends AbstractCardPanel{
    private JPanel questPanel = new JPanel();
    private GridBagLayout gridBag = new GridBagLayout();
    private GridBagLayout gridBagQuest = new GridBagLayout();
    private JButton addQuestButton;
    private List<Quest> questList = new ArrayList<>();
    private List<JPanel> questPanelList = new ArrayList<>();
    private int currentX;
    private int currentY;

    public QuestPanel(List<Quest> questList, QuestGui questGui){
        panel = new JPanel();
        panel.setBorder(BORDER);
        panel.setLayout(gridBag);
        this.questGui = questGui;
        frame = questGui.getFrame();
        cardNum = 1;
        currentX = 0;
        currentY = 0;

        questPanel.setLayout(new GridLayout(0,4));
        questPanel.setBorder(COMBINED);
        addGridBagConstraint(questPanel, panel, currentX, currentY, 2, 4, 1, currentX, false, true);
        currentY += 10;

        for (Quest q : questList){
            addQuest(q);
        }

        addQuestButton = new JButton("Add Quest");
        addGridBagConstraint(addQuestButton, panel, currentX, currentY, 1, 1, 1, currentX, false, true);
        currentY += 1;
        addQuestGuiListeners(questGui);
        frame.revalidate();
        frame.repaint();
    }

    private void addGridBagConstraint(Component c, JPanel panel, int x, int y, int width, int height, double weighting, int currentX, boolean extraRow, boolean fill){
        GridBagConstraints gbc = new GridBagConstraints();
        if (fill){
            gbc.fill = GridBagConstraints.HORIZONTAL;
        }
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridheight = width;
        gbc.gridwidth = height;
        gbc.weightx = weighting;
        panel.add(c,gbc);

        if (extraRow){
            currentX += 1;
        } else {
            currentX = 0;
        }
    }

    public void addQuest(Quest quest){
        JPanel singleQuestPanel = new JPanel();
        singleQuestPanel.setLayout(gridBagQuest);
        singleQuestPanel.setOpaque(true);
        singleQuestPanel.setBackground(menuBg);
        int questX = 0;
        int questY = 0;

        createQuest(singleQuestPanel, quest, questX, questY);
        singleQuestPanel.setBorder(BORDER);
        
        questPanel.add(singleQuestPanel);
        questPanelList.add(singleQuestPanel);
        questList.add(quest);
    }

    private void createQuest(JPanel singleQuestPanel, Quest quest, int questX, int questY){

        JLabel title = new JLabel(quest.getTitle());
        addGridBagConstraint(title, singleQuestPanel, questX, questY, 1, 1, 0.5, questX, false, false);
        questY += 1;
        if (!quest.getDesc().equals("")){
            JLabel desc = new JLabel(quest.getDesc());
            addGridBagConstraint(desc, singleQuestPanel, questX, questY, 1, 1, 0.5, questX, false, false);
            questY += 1;
        }

        int sqCounter = 0;
        for (SubQuest subQuest : quest.getSubQuests()){
            JPanel subQuestPanel = new JPanel(new GridBagLayout());

            JButton subQuestIncrement = new JButton("^");
            subQuestIncrement.setMargin(new Insets(0,0,0,0));
            subQuestIncrement.setName(String.valueOf(sqCounter));
            subQuestIncrement.setPreferredSize(new Dimension(20,20));
            addGridBagConstraint(subQuestIncrement, subQuestPanel, 0, questY, 1, 1, 0, questX, true, false);
            addIncrementListener(subQuestIncrement);
            if (subQuest.getMax() == 0){
                JLabel singleSQ = new JLabel(subQuest.getDesc());
                addGridBagConstraint(singleSQ, subQuestPanel, 1, questY, 1, 1, 0, questX, true, false);
            } else {
                JLabel multiSQ = new JLabel(subQuest.getVal() + "/" + subQuest.getMax() + " : " + subQuest.getDesc());
                addGridBagConstraint(multiSQ, subQuestPanel, 2, questY, 1, 1, 0, questX, true, true);
            }
            subQuestPanel.setBorder(BORDER);
            addGridBagConstraint(subQuestPanel, singleQuestPanel, 0, currentY, 1, 1, 0, 0, false, false);
            questX += 1;
            currentY += 1;
            sqCounter += 1;
        }
        JButton removeQuest = new JButton("Remove Quest");
        removeQuest.setPreferredSize(new Dimension(50,20));
        addRemoveListener(removeQuest);
        addGridBagConstraint(removeQuest, singleQuestPanel, currentX, currentY, 1, 1, 0.5, questX, false, true);
    }

    private void setSubQuestLabels(JPanel singleQuestPanel, SubQuest subQuest){

        //removes title and description from list
        Component[] panelComponents = singleQuestPanel.getComponents();
        JLabel textLabel = (JLabel)panelComponents[1];

        if (subQuest.getVal() != subQuest.getMax()){
            textLabel.setText(subQuest.getVal() + "/" + subQuest.getMax() + " : " +subQuest.getDesc());
        } else {
            subQuest.complete();
            textLabel.setText(subQuest.getVal() + "/" + subQuest.getMax() + " : " +subQuest.getDesc());
            Font font = textLabel.getFont();
            Map<TextAttribute, Object> attributes = new HashMap<>();
            attributes.put(TextAttribute.STRIKETHROUGH, TextAttribute.STRIKETHROUGH_ON);
            Font newFont = font.deriveFont(attributes);
            textLabel.setFont(newFont);
            singleQuestPanel.remove(panelComponents[0]);
            frame.revalidate();
            frame.repaint();
        }
    }

    private void addIncrementListener(JButton button){
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                incrementSubQuest(button);
            }
        });
    }

    private void incrementSubQuest(JButton button){
        Component panel = button.getParent().getParent();
        int index = searchPanelList(panel);
        Quest q = questList.get(index);
        int sqIndex = Integer.valueOf(button.getName());
        SubQuest sq = q.findSubQuest(sqIndex);
        sq.incrementValue();
        setSubQuestLabels((JPanel)button.getParent(), sq);
        boolean checker = checkQuestComplete(q);
        if (checker){
            q.complete();
            questCompleted((JPanel) panel, q);
        }
        frame.revalidate();
        frame.repaint();
    }

    private boolean checkQuestComplete(Quest q){
        int complete = 0;
        int total = 0;
        for (SubQuest itm : q.getSubQuests()){
            total += 1;
            if (itm.isComplete()){
                complete += 1;
            }
        }
        if (total == complete){
            return true;
        } else  {
            return false;
        }
    }


    private void questCompleted(JPanel panel, Quest q){
        panel.removeAll();
        //add plus point gui element
        panel.getParent().remove(panel);
        questGui.addPoints(10);

    }

    private void addRemoveListener(JButton button){
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                JPanel singleQuestP = (JPanel)button.getParent();
                int index = searchPanelList(singleQuestP);
                questList.remove(index);
                questPanel.remove(singleQuestP);
                frame.revalidate();
                frame.repaint();
            }
        });
    }

    private void addQuestGuiListeners(QuestGui questGui){
        addQuestButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                questGui.setCurrentCard(2);
            }
        });
    }

    private int searchPanelList(Component searchTerm){
        for (int i = 0; i < questPanelList.size(); i++){
            if (questPanelList.get(i) != null && questPanelList.get(i).equals(searchTerm)) {
                return i;
            }
        }
        return -1;
    }

    private int searchQuestList(Quest searchTerm){
        for (int i = 0; i < questList.size(); i++){
            if (questList.get(i) != null && questList.get(i).equals(searchTerm)) {
                return i;
            }
        }
        return -1;
    }



    
    
}
