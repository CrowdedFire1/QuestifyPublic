package CardPanels;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.io.File;

import Gui.QuestGui;
import Gui.SaveFile;
import Questify.QuestifyRun;

public class SettingsPanel extends AbstractCardPanel{

    private List<JTextField> colourFields = new ArrayList<>();
    private List<Color> currentColors = new ArrayList<>();

    private Map<String, Color> allColors = new HashMap<>();
    private List<Color> defaultColours = new ArrayList<>();
    private Color bg = new Color(241, 222, 198);
    private Color menuBg = new Color(23, 155, 174);
    private Color titleBg = new Color(255, 131, 67);
    private Color buttonBg = new Color(65, 88, 166);

    JLabel errorLabel = new JLabel();
    int currentX = 0;
    int currentY = 0;
    public static int fontSize = 10;

    public SettingsPanel(QuestGui questGui){

        this.questGui = questGui;
        frame = this.questGui.getFrame();
        panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBorder(COMBINED);

        JLabel info = new JLabel("Enter the Colours you wish to change.");
        
        JLabel info2 = new JLabel("If you do not wish to change a colour, leave the field blank.");
        JLabel info3 = new JLabel(" If you wish to go back to the default colour, type default.");
        addGridBagConstraint(info, panel, 1, true);
        addSpacer(false);
        currentY += 1;

        addGridBagConstraint(info2, panel, 1, true);
        addSpacer(false);
        currentY += 1;
        addGridBagConstraint(info3, panel, 1, true);
        addSpacer(false);
        currentY += 1;

        //adds errorLabel
        addGridBagConstraint(errorLabel, panel, 0, true);
        currentX = 0;
        currentY += 1;

        JLabel mainBGLabel = new JLabel("Main Background Colour: ");
        addGridBagConstraint(mainBGLabel, panel, 1, true);

        JTextField mainBGText = new JTextField();
        addGridBagConstraint(mainBGText, panel, 1, true);
        currentY += 1;


        JLabel menuBGLabel = new JLabel("Menu Background Colour: ");
        addGridBagConstraint(menuBGLabel, panel, 1, true);

        JTextField menuBGText = new JTextField();
        addGridBagConstraint(menuBGText, panel, 1, true);
        currentY += 1;


        JLabel titleBGLabel = new JLabel("Title Background Colour: ");
        addGridBagConstraint(titleBGLabel, panel, 1, true);

        JTextField titleBGText = new JTextField();
        addGridBagConstraint(titleBGText, panel, 1, true);
        currentY += 1;


        JLabel buttonBGLabel = new JLabel("Button Background Colour: ");
        addGridBagConstraint(buttonBGLabel, panel, 1, true);

        JTextField buttonBGText = new JTextField();
        addGridBagConstraint(buttonBGText, panel, 1, true);
        currentY += 1;


        //adds textfields to a list
        colourFields.add(mainBGText);
        colourFields.add(menuBGText);
        colourFields.add(titleBGText);
        colourFields.add(buttonBGText);

        //adds current default colours to list
        currentColors.add(bg);
        currentColors.add(menuBg);
        currentColors.add(titleBg);
        currentColors.add(buttonBg);

        //forms all color - string name pairs
        allColors.put("black", Color.black);
        allColors.put("blue", Color.blue);
        allColors.put("cyan", Color.cyan);
        allColors.put("dark grey", Color.darkGray);
        allColors.put("grey", Color.gray);
        allColors.put("green", Color.green);
        allColors.put("light grey", Color.lightGray);
        allColors.put("magenta", Color.magenta);
        allColors.put("orange", Color.orange);
        allColors.put("pink", Color.pink);
        allColors.put("red", Color.red);
        allColors.put("white", Color.white);
        allColors.put("yellow", Color.yellow);

        //adds default colours
        defaultColours.add(bg);
        defaultColours.add(menuBg);
        defaultColours.add(titleBg);
        defaultColours.add(buttonBg);



        JButton changeButton = new JButton("Apply Changes");
        addGridBagConstraint(changeButton, panel, 1, true);
        addChangeListener(changeButton);
        addSpacer(false);
        currentY += 1;

        addSpacer(true);
        addSpacer(true);
        addSpacer(true);
        addSpacer(true);

        JButton saveButton = new JButton("Save");
        addSaveListener(saveButton);
        addGridBagConstraint(saveButton, panel, 1, true);
        addSpacer(false);
        currentY += 1;

        addSpacer(true);

        JButton quitButton = new JButton("Save & Quit");
        addQuitListener(quitButton);
        addGridBagConstraint(quitButton, panel, 1, true);
        addSpacer(false);

    }

    private void addSpacer(boolean gap){
        JLabel blankLabel = new JLabel();
        if (gap){
            blankLabel.setBorder(GAP);
        }
        addGridBagConstraint(blankLabel, panel, 0, true);
        currentY += 1;
    }

    private void addChangeListener(JButton b){
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                int colourCounter = 0;
                List<Color> newColours = new ArrayList<>();
                for (JTextField itm : colourFields){
                    String text = itm.getText();
                    text = text.toLowerCase();
                    if (!text.equals("")){
                        String type = parseString(text);
                        switch(type){
                            case "rgb":
                                String[] nums = text.split(",");
                                Color newCrgb = new Color(Integer.valueOf(nums[0]), Integer.valueOf(nums[1]), Integer.valueOf(nums[2]));
                                newColours.add(newCrgb);
                                currentColors.set(colourCounter, newCrgb);
                                break;
                            case "hex":
                                Color newChex = Color.decode(text);
                                newColours.add(newChex);
                                currentColors.set(colourCounter, newChex);
                                break;
                            case "default":
                                newColours.add(defaultColours.get(colourCounter));
                                break;
                            case "name":
                                Color found = searchHash(text);
                                if (found != null){
                                    newColours.add(found);
                                    currentColors.set(colourCounter, found);
                                } else {
                                    newColours.add(currentColors.get(colourCounter));
                                    addErrorMessage("No named Colour, please use rgb or hex code instead.");
                                }
                                break;
                        }
                    } else {
                        newColours.add(currentColors.get(colourCounter));
                    }
                    colourCounter += 1;
                }
                setColours(newColours);
                frame.revalidate();
                frame.repaint();
            }
        });
    }

    private void addSaveListener(JButton b){
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                save();
            }
        });
    }


    private void addQuitListener(JButton b){
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                save();
                System.exit(0);
            }
        });
    }

    public void save(){
        File saveFile = QuestifyRun.getSaveFile();
        saveFile.delete();

        new SaveFile(questGui.getQuestList(), questGui.getColourList(), fontSize);
    }


    private void addGridBagConstraint(Component c, JPanel attachedPanel, int end, boolean fill){
        GridBagConstraints gbc = new GridBagConstraints();
        if (fill){
            gbc.fill = GridBagConstraints.HORIZONTAL;
        }
        
        gbc.gridx = currentX;
        gbc.gridy = currentY;
        if (c instanceof JLabel || c instanceof JButton){
            gbc.weightx = 0.0;
        } else {
            gbc.weightx = 1;
        }
        attachedPanel.add(c,gbc);

        if (currentX >= end){
            currentX = 0;
        } else {
            currentX = 1;
        }
    }

    private void addErrorMessage(String msg){
        errorLabel.setText(msg);
    }

    private Color searchHash(String key){
        Color found = allColors.get(key);
        return found;
    }

    private String parseString(String text){
        String[] textA = text.split("");
        if (text.split(",").length > 1){
            return "rgb";
        }
        if (textA[0].equals("#")){
            return "hex";
        }
        if (text.equals("default")){
            return "default";
        }
        return "name";
    }

    public void setColours(List<Color> c){
        questGui.updateColours(c);
        frame.revalidate();
        frame.repaint();
    }
}
