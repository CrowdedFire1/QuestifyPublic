package CardPanels;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

import Gui.Quest;
import Gui.QuestGui;
import Gui.SubQuest;


public class NewQuestPanel extends AbstractCardPanel{

    //used to store add value positions
    private int currentX;
    private int currentY;
    private int addValueCounter;

    //used to add components at a given index
    private GridBagLayout gridBag = new GridBagLayout();

    //tracks x and y of each value add check box
    List<Integer> addValueCurrentX = new ArrayList<>();
    List<Integer> addValueCurrentY = new ArrayList<>();
    //tracks all components on the newQuest board
    List<Component> trackAllComponents = new ArrayList<>();

    //used to store each pair of addvalue extras
    List<Component> addValueOptions = new ArrayList<>();

    //list of checkboxes
    List<Component> addValueCheckbox = new ArrayList<>();

    //list of subQuests
    List<SubQuest> subQuestList = new ArrayList<>();

    //list of subquest components
    List<List<Component>> subQuestComponents = new ArrayList<>();
    int subQCounter = 0;

    //tracks the add quest button and attached blank label
    JButton addQuestButton;
    JLabel blankLabel;

    
    public NewQuestPanel(QuestGui questGui){
        panel = new JPanel();
        panel.setBorder(COMBINED);
        panel.setLayout(gridBag);
        cardNum = 2;

        this.questGui = questGui;
        frame = questGui.getFrame();
        JLabel warning1 = new JLabel("Warning: Don't use commas or tilda (~)");
        addGridBagConstraint(warning1, panel, 1, 0.5, false);
        addSpacer();
        /*JLabel warning2 = new JLabel("This will cause corruption of the savefile, which would need manual changing.");
        addGridBagConstraint(warning2, panel, 1, 0.5, false);
        addSpacer();
        warning2.setBorder(GAP);*/

        JLabel title = new JLabel("Quest Title: ");
        title.setBorder(GAP);
        addGridBagConstraint(title, panel, 1, 0.5, true);

        JTextField titleInput = new JTextField();
        titleInput.setBorder(BORDER);
        addGridBagConstraint(titleInput, panel, 1, 0.5, true);
        currentY += 1;
        
        JLabel desc = new JLabel("Quest Description: ");
        desc.setBorder(GAP);
        addGridBagConstraint(desc, panel, 1, 0.5, true);

        JTextField descInput = new JTextField();
        descInput.setBorder(BORDER);
        addGridBagConstraint(descInput, panel, 1, 0.5, true);
        currentY += 1;

        JButton addSubQuestB = new JButton("Add SubQuest");
        addSubQuestB.setBorder(COMBINED);

        addGridBagConstraint(addSubQuestB, panel, 1, 0.25, false);

        addSpacer();

        addSubQuestListener(addSubQuestB, panel);
        

        addQuestButton = new JButton("Add Quest");
        addQuestButton.setBorder(COMBINED);
        addGridBagConstraint(addQuestButton, panel, 1, 0.5, true);
        blankLabel = new JLabel();
        blankLabel.setBorder(GAP);
        addGridBagConstraint(blankLabel, panel, 1, 0.75, true);
        addQuestListener(addQuestButton);

    }

    private void addSpacer(){
        JLabel blankGrid = new JLabel();
        blankGrid.setBorder(GAP);
        addGridBagConstraint(blankGrid, panel, 1, 0.75, true);
        currentY += 1;
    }


    private void makeComponentLast(Component comp){
        panel.remove(comp);

        int index = searchComponentList(comp);
        trackAllComponents.remove(index);
        addGridBagConstraint(comp, panel, 1, 0.5, true);
    }

    private void addQuestListener(JButton button){
        button.addActionListener(new ActionListener() {
            List<String> questData = new ArrayList<>();
            
            public void actionPerformed(ActionEvent e){
                for (int  i = 0; i < trackAllComponents.size(); i++){
                    Component comp = trackAllComponents.get(i);
                    
                    if (comp instanceof JTextField){
                        questData.add(((JTextField)comp).getText());
                        ((JTextField)comp).setText(""); 
                    }
                    if (comp instanceof JCheckBox){
                        String check = String.valueOf(((JCheckBox)comp).isSelected());
                        questData.add(check);
                        ((JCheckBox)comp).setSelected(false);
                    }
                    if (comp instanceof JSpinner){
                        questData.add(String.valueOf(((JSpinner)comp).getValue()));
                    }
                }
                parseQuestData(questData);
                //desc quest if no subquest turn into subquest
                if (subQuestList.isEmpty()){
                    String qd = questData.get(1);
                    SubQuest sq = new SubQuest(qd, 1);
                    subQuestList.add(sq);
                    questData.set(1, "");
                }
                Quest q = new Quest(subQuestList, questData.get(0), questData.get(1));
                questGui.addQuestGui(q);
                questGui.setCurrentCard(1);
                subQuestList.clear();
                questGui.hardReset(cardNum);
            }
        });
    }

    private void parseQuestData(List<String> questData){
        for (int o = 2; o < questData.size(); o++){
            String checkbox = questData.get(o);
            String data = null;
            int maxValue = -1;
            if (checkbox.equals("true")){
                data = questData.get(o-1);
                maxValue = Integer.valueOf(questData.get(o+1));
            }
            if (checkbox.equals("false")){
                data = questData.get(o-1);
                maxValue = 1;
            }
            if (data != null){
                SubQuest sq = addSubQuest(data, maxValue);
                subQuestList.add(sq);
            }
        }
    }

    public SubQuest addSubQuest(String desc, int max){
        SubQuest sq = new SubQuest(desc, max);
        return sq;
    }

    public void addSubQuestListener(JButton button, JPanel attatchedPanel){
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                subQCounter += 1;
                List<Component> subQuestComp = new ArrayList<>();
                JLabel subDesc = new JLabel("Sub Quest Description: ");
                subDesc.setBorder(BorderFactory.createEmptyBorder(20,10,10,10));
                addGridBagConstraint(subDesc, attatchedPanel, 1, 0.5, true);
                subQuestComp.add(subDesc);

                JTextField subDescInput = new JTextField();
                subDescInput.setBorder(BorderFactory.createEmptyBorder(20,10,10,10));
                subDescInput.setBorder(BORDER);
                addGridBagConstraint(subDescInput, attatchedPanel, 1, 0.5, true);
                subQuestComp.add(subDescInput);
                currentY += 1;

                JCheckBox addValues = new JCheckBox("Add Value");
                addValues.setName(String.valueOf(addValueCounter));
                addValues.setBorder(GAP);
                addValues.setBorder(BORDER);
                addValueCheckbox.add(addValueCounter, addValues);

                addValueCurrentX.add(Integer.valueOf(addValues.getName()), currentX);
                addValueCurrentY.add(Integer.valueOf(addValues.getName()), currentY);
                addValueCounter += 1;

                addGridBagConstraint(addValues, attatchedPanel, 1, 0.05, false);
                subQuestComp.add(addValues);

                JButton removeSub = new JButton("Remove SubQuest " + subQCounter);
                removeSub.setBorder(COMBINED);
                removeSub.setPreferredSize(new Dimension(200,30));
                addGridBagConstraint(removeSub, attatchedPanel, 1, 0.95,false);
                subQuestComp.add(removeSub);
                currentY += 1;
                
                addValueCheckListener(addValues, attatchedPanel);
                addRemoveSubQuestListener(removeSub, attatchedPanel);

                subQuestComponents.add(subQuestComp);
                makeComponentLast(addQuestButton);
                makeComponentLast(blankLabel);
                frame.revalidate();
                frame.repaint();
            }
        });
    }


    public int findCheckBox(JCheckBox check){
        boolean found = false;
        for (int i = 0; i < subQuestComponents.size(); i++){
            for (int j = 0; j < subQuestComponents.get(i).size(); j++){
                List<Component> subQ = subQuestComponents.get(i);
                if (subQ.get(j) instanceof JCheckBox && subQ.get(j).equals(check)){
                    found = true;
                }
            }
            if (found){
                return i;
            }
        }
        return -1;
    }


    private void addValueCheckListener(JCheckBox checkBox, JPanel attatchedPanel){
        
        checkBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                JLabel subMax = null;
                JSpinner subMaxInput = null;
                JCheckBox box = (JCheckBox)e.getSource();
                if (box.isSelected() == true){

                    int subQIndex = findCheckBox(box);

                    int index = Integer.valueOf(box.getName());
                    subMax = new JLabel("Max: ");
                    subMax.setBorder(GAP);

                    int indexX = (int)addValueCurrentX.get(index);
                    int indexY = (int)addValueCurrentY.get(index);

                    
                    addGridBagConstraintIndex(subMax, attatchedPanel, 1, 0.5, indexX, indexY+1, true);
                    if (addValueOptions.size() < index){
                        addNullCompList(addValueOptions, index);
                    }
                    addValueOptions.add(index,subMax);

                    subMaxInput = new JSpinner(new SpinnerNumberModel());
                    subMaxInput.setBorder(GAP);
                    subMaxInput.setBorder(BORDER);

                    
                    addGridBagConstraintIndex(subMaxInput, attatchedPanel, 1, 0.5, indexX+1, indexY+1, false);
                    if (addValueOptions.size() < index){
                        addNullCompList(addValueOptions, index);
                    }
                    addValueOptions.add(index+1,subMaxInput);
                    
                    currentY += 1;

                    subQuestComponents.get(subQIndex).add(subMax);
                    subQuestComponents.get(subQIndex).add(subMaxInput);

                    makeComponentLast(addQuestButton);
                    makeComponentLast(blankLabel);

                    frame.revalidate();
                    frame.repaint();
                } else {
                    int index = Integer.valueOf(box.getName());
                    attatchedPanel.remove(addValueOptions.get(index));
                    attatchedPanel.remove(addValueOptions.get(index+1));

                    int ind = searchComponentList(addValueOptions.get(index));
                    trackAllComponents.remove(ind);

                    ind = searchComponentList(addValueOptions.get(index+1));
                    trackAllComponents.remove(ind);

                    addValueOptions.remove(index);
                    addValueOptions.remove(index);

                    int boxIndex = searchCheckList(box);
                    int offset = -1;

                    for (int o = boxIndex+1; o < addValueCheckbox.size(); o++){
                        JCheckBox other = (JCheckBox)addValueCheckbox.get(o);
                        int otherIndex = Integer.valueOf(other.getName());
                        int currY = addValueCurrentY.get(otherIndex);
                        addValueCurrentY.set(otherIndex,currY+offset);

                    }
                    currentY -= 1;
                    currentX = 0;
                    
                    frame.revalidate();
                    frame.repaint();
                }
            }
        });
    }


    public void addRemoveSubQuestListener(JButton button, JPanel panel){
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                removeSubQuest(button, panel);
            }
        });
    }


    public void removeSubQuest(JButton button, JPanel panel){
        int index = Integer.valueOf((button.getText()).replace("Remove SubQuest ", "")) - 1;
        List<Component> itemsToRemove = subQuestComponents.get(index);
        for (Component itm : itemsToRemove){
            panel.remove(itm);
        }
        subQuestComponents.remove(index);
        subQCounter -= 1;
        renameSubQuests(button, panel, index);
        frame.revalidate();
        frame.repaint();
    }

    public void renameSubQuests(JButton button, JPanel panel, int index){
        for (int i = index; i < subQuestComponents.size(); i++){
            for (int j = 0; j < subQuestComponents.get(i).size(); j++){
                List<Component> subQ = subQuestComponents.get(i);
                if (subQ.get(j) instanceof JCheckBox){
                    ((JButton)subQ.get(j+1)).setText("Remove SubQuest " + subQCounter);
                }
            }
        }
    }


    private void addGridBagConstraint(Component c, JPanel attachedPanel, int end, double weighting, boolean fill){
        GridBagConstraints gbc = new GridBagConstraints();
        if (fill){
            gbc.fill = GridBagConstraints.HORIZONTAL;
        }
        gbc.gridx = currentX;
        gbc.gridy = currentY;
        gbc.weightx = weighting;
        attachedPanel.add(c,gbc);
        trackAllComponents.add(c);
    
        if (currentX >= end){
            currentX = 0;
        } else {
            currentX = 1;
        }
    }


    public void addGridBagConstraintIndex(Component c, JPanel attachedPanel, int end, double weighting, int indexX, int indexY, boolean move){
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = weighting;
        gbc.gridx = indexX;
        gbc.gridy = indexY;
        gridBag.setConstraints(c, gbc);
        attachedPanel.add(c);
        int newSize = indexX+indexY*2;
        if (trackAllComponents.size() < newSize){
            addNullCompList(trackAllComponents, newSize);
        }
        trackAllComponents.add(newSize, c);

        if (move == true){
            int index = searchComponentList(c);
            //skips the second column component
            index += 1;
            if (index != -1){
                if (index < trackAllComponents.size()){
                    moveComponents(index, 1);
                }
            } else {
                System.out.println("Error no search term found");
            }
        }

        
        if (currentX >= end){
            currentX = 0;
        } else {
            currentX = 1;
        }

        frame.revalidate();
        frame.repaint();
    }

    private void addNullCompList(List<Component> list, int newSize){
        for (int i = 0; i < newSize-list.size()+1; i++){
            list.add(null);
        }
    }

    public int countNotNullCompList(List<Component> list){
        int cnt = 0;
        for(Component i : list){
            if (i != null){
                cnt += 1;
            }
        }
        return cnt;
    }

    private int searchComponentList(Component searchTerm){
        for (int i = 0; i < trackAllComponents.size(); i++){
            if (trackAllComponents.get(i) != null && trackAllComponents.get(i).equals(searchTerm)) {
                return i;
            }
        }
        return -1;
    }

    private int searchCheckList(Component searchTerm){
        for (int i = 0; i < addValueCheckbox.size(); i++){
            if (addValueCheckbox.get(i) != null && addValueCheckbox.get(i).equals(searchTerm)) {
                return i;
            }
        }
        return -1;
    }

    
    private void moveComponents(int index, int offset){
        for (int i = index; i < trackAllComponents.size(); i++){
            Component comp = trackAllComponents.get(i);
            if (trackAllComponents.get(i) != null){
                GridBagLayout gbl = (GridBagLayout)panel.getLayout();
                GridBagConstraints cons = gbl.getConstraints(comp);
                cons.gridy += offset;
                int newY = cons.gridy;
                gridBag.setConstraints(comp, cons);
                if (comp instanceof JCheckBox){
                    int compIndex = searchCheckList(comp);
                    addValueCurrentY.set(compIndex, newY);
                }
            }
        }
    }

    @Override
    public void changeColour(List<Color> c){
        super.changeColour(c);
        
    }
}
