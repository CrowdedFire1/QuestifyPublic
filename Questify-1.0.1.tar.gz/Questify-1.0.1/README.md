# Welcome to Questify! A to-do List with rewards.
To help with doing any tasks you like.
How it works:
Create quests with optional values.
Then once complete, tick the quest off to earn points.
Redeem points in the shop to buy outfits for your person.


## Under the hood:

### Java Swing layouts Structure:
* mainPanel is a borderlayout.
  * The Center box has a card layout to switch what is displayed.
    * Each Individual quest has a panel to order quest, with a inner panel for each subquests.
  * The West box is the menu which has a box layout for vertical stacking of buttons. 
  * The East Box has the person showing off the current selected outfit.
    * The North Box contains the title.

### Settings
* Colours are set via calls to the QuestGui (and technically the cardpanels due to me messing around and not removing code :))
* Saving is done using a text file which stores all the quests, colours and font size (not yet implemented)
* Commas and tilda (~) cant be used in quests because they are the delimiters used in the text file and it will corrupt the savefile if you use them 
