package Questify;

import javax.swing.*;

import Gui.QuestGui;
import Gui.SaveFile;
import Gui.Quest;
import Gui.SaveFile;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;

public class QuestifyRun {

    public static List<Color> defaultColours = new ArrayList<>();
    private static int defaultFontSize = 0;
    private Color bg = new Color(241, 222, 198);
    private Color menuBg = new Color(23, 155, 174);
    private Color titleBg = new Color(255, 131, 67);
    private Color buttonBg = new Color(65, 88, 166);

    private static File saveFile; 

    public QuestifyRun(){

        defaultColours.add(bg);
        defaultColours.add(menuBg);
        defaultColours.add(titleBg);
        defaultColours.add(buttonBg);

        new SaveFile(null, defaultColours, 10);
        new QuestGui(500,500, null);
        //finds newly created savefile
        File sf = new File("savefile.txt");
        QuestifyRun.saveFile = sf;
    }

    public QuestifyRun(File saveFile) throws FileNotFoundException{
        try{
            QuestifyRun.saveFile = saveFile;
            List<Quest> qs = SaveFile.readFile(saveFile, false);
            new QuestGui(500,500, qs);
        } catch (FileNotFoundException e){
            throw new FileNotFoundException();
        }
    }

    public static void setDefaultColours(List<Color> c){
        defaultColours = c;
    }

    public static void setDefaultFontSize(int fs){
        defaultFontSize = fs;
    }

    public static File getSaveFile(){
        return saveFile;
    }

    public static void main(String[] args){
        try {
            File saveFile = new File("savefile.txt");
            QuestifyRun start = new QuestifyRun(saveFile);
        } catch (NullPointerException | FileNotFoundException e){
            System.out.println("No Save File Detected. Creating new File.");
            QuestifyRun start = new QuestifyRun();
        }
    }
}
