package Gui;

import java.util.ArrayList;
import java.util.List;
import Questify.QuestifyRun;

import java.awt.Color;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedWriter;

import CardPanels.SettingsPanel;

import java.io.FileNotFoundException;

public class SaveFile {
    
    public SaveFile(List<Quest> quests, List<Color> c, int fontSize){
        File savefile = new File("savefile.txt");

        try{
            FileWriter fileWriter = new FileWriter(savefile);
            BufferedWriter fileWrite = new BufferedWriter(fileWriter);
            fileWrite.write("Quests");
            fileWrite.newLine();
            if (quests != null){
                for (Quest itm : quests){
                    fileWrite.write(itm.getString());
                    fileWrite.newLine();
                }
            }

            fileWrite.write("Colours");
            fileWrite.newLine();
            for (Color itm : c){
                String comma = ",";
                String rgb = String.valueOf(itm.getRed()) + comma + String.valueOf(itm.getGreen()) + comma + String.valueOf(itm.getBlue());
                fileWrite.write(rgb);
                fileWrite.newLine();
            }

            fileWrite.write("Font Size:" + fontSize);
            fileWrite.close();
        } catch (IOException e){
            System.out.println("Error no save file. ");
            e.printStackTrace();
        } catch (Exception e){
            System.out.println("Writing Error. ");
            e.printStackTrace();
        }
    }

    public static List<Quest> readFile(File saveFile, Boolean handleErrors) throws FileNotFoundException{
        List<Quest> quests = new ArrayList<>();
        List<Color> colours = new ArrayList<>();
        try{
            Scanner readFile = new Scanner(saveFile);
            while(readFile.hasNextLine()){
                String data = readFile.nextLine();
                if (data.equals("Quests")){
                    data = readFile.nextLine();
                    while (!data.equals("Colours")){
                        data = readFile.nextLine();
                        String[] splitData = data.split(",");
                        List<SubQuest> sqs = createSubQuests(splitData);
                        Quest q = new Quest(sqs, splitData[0], splitData[1]);
                        quests.add(q);
                    }
                }
                if (data.equals("Colours")){
                    for (int i = 0; i < 4; i++){
                        data = readFile.nextLine();
                        String[] dataSplit = data.split(",");
                        Color c = new Color(Integer.valueOf(dataSplit[0]), Integer.valueOf(dataSplit[1]), Integer.valueOf(dataSplit[2]));
                        colours.add(c);
                    }
                    QuestifyRun.setDefaultColours(colours);
                }
                data = readFile.nextLine();
                if (data.contains("Font Size:")){
                    String dataChange = data;
                    dataChange = dataChange.replace("Font Size:", "");
                    int fontSize = Integer.valueOf(dataChange);
                    QuestifyRun.setDefaultFontSize(fontSize);
                }
            }
            readFile.close();
        } catch (FileNotFoundException e){
            if (handleErrors){
                System.out.println("File Not Found. ");
                e.printStackTrace();
            }
            throw new FileNotFoundException();
        } catch (NumberFormatException e){
            System.out.println("Parsing Error. ");
            e.printStackTrace();
        }
        List<List<Object>> returnList = new ArrayList<>();
        
        return quests;
    }

    private static List<SubQuest> createSubQuests(String[] splitData){
        List<SubQuest> sqs = new ArrayList<>();
        
        for (int i = 2; i < splitData.length; i+=3){
            String[] sqSplit = splitData[i].split("~");
            SubQuest sq = new SubQuest(sqSplit[i], Integer.valueOf(sqSplit[i+1]), Integer.valueOf(sqSplit[i+2]));
            sqs.add(sq);
        }
        return sqs;
    }
}
