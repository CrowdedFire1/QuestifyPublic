package Gui;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import CardPanels.NewQuestPanel;
import CardPanels.OutfitsPanel;
import CardPanels.QuestPanel;
import CardPanels.SettingsPanel;
import Questify.QuestifyRun;

import java.awt.*;
import java.awt.event.*;

import java.util.ArrayList;
import java.util.List;
import java.io.File;

public class QuestGui extends JFrame{
    private final int WIDTH = 700;
    private final int HEIGHT = 700;
    private final Border BORDER = BorderFactory.createLineBorder(Color.black, 1);
    private List<Color> colours = new ArrayList<>();
    private static Color bg = new Color(241, 222, 198);
    private static Color menuBg = new Color(23, 155, 174);
    private static Color titleBg = new Color(255, 131, 67);
    private static Color buttonBg = new Color(65, 88, 166);

    //used to store the panels
    private JPanel questPanel;
    private JPanel centerPanel;
    private JPanel newQuestPanel;
    private JPanel outfitPanel;
    private JPanel settingsPanel;
    private JPanel menuPanel;
    private JPanel mainPanel;
    private static JFrame frame;
    

    private static List<JPanel> panelList = new ArrayList<>();

    //used to store the panel classes
    private QuestPanel questPanelClass;
    private NewQuestPanel newQuestPanelClass;
    private SettingsPanel settingsPanelClass;
    private OutfitsPanel outfitPanelClass;

    private List<Quest> questList = new ArrayList<>();

    //quests = 1, newQuest = 2, outfits = 3, settings = 4
    private String currentCard;

    //points tracker
    private int points = 0;

    //sets up points display
    private JLabel pointsDisplay = new JLabel();

    public QuestGui(int width, int height, List<Quest> quests){

        //sets window up
        frame = new JFrame();
        frame.setTitle("Questify");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(WIDTH,HEIGHT);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);

        
        

        //sets the card to be displayed by default to 1
        currentCard = "1";

        //main panel controlling main layout
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(titleBg);

        //handles the title area
        JLabel mainTitle = new JLabel("Questify");
        mainPanel.add(mainTitle, BorderLayout.NORTH);

        //uses cardlayout to switch what the center piece is
        centerPanel = new JPanel(new CardLayout());
        mainPanel.add(centerPanel, BorderLayout.CENTER);


        if (quests != null){
            questList = quests;
        }
        //sets up quest center piece
        questPanelClass = new QuestPanel(questList, this);
        questPanel = questPanelClass.getPanel();

        //sets up outfit center 
        outfitPanelClass = new OutfitsPanel();
        outfitPanel = outfitPanelClass.getPanel();
        
        //sets up settings center piece
        settingsPanelClass = new SettingsPanel(this);
        settingsPanel = settingsPanelClass.getPanel();

        //sets up newQuest center piece
        newQuestPanelClass = new NewQuestPanel(this);
        newQuestPanel = newQuestPanelClass.getPanel();
        
        questPanel.setBackground(bg);
        outfitPanel.setBackground(bg);
        settingsPanel.setBackground(bg);
        newQuestPanel.setBackground(bg);

        //adding all cards onto center piece
        centerPanel.add("1", questPanel);
        centerPanel.add("2", newQuestPanel);
        centerPanel.add("3", outfitPanel);
        centerPanel.add("4", settingsPanel);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        //handles the menuing of the app
        JButton questButton = new JButton("Quests");
        JButton outfitButton = new JButton("Outfits");
        JButton newQuestButton = new JButton("New Quest");
        JButton settingButton = new JButton("Settings");

        //intialises points tracker
        pointsDisplay.setBorder(BorderFactory.createCompoundBorder(BORDER, new EmptyBorder(10,10,10,10)));
        pointsDisplay.setBackground(titleBg);
        pointsDisplay.setOpaque(true);
        updatePointsDisplay();

        //add menu items
        menuPanel = new JPanel();
        menuPanel.setBackground(menuBg);
        menuPanel.setLayout(new GridBagLayout());
        menuGBC(menuPanel, questButton, 0);
        menuGBC(menuPanel, newQuestButton, 1);
        menuGBC(menuPanel, outfitButton, 2);
        menuGBC(menuPanel, settingButton, 3);
        menuGBC(menuPanel, pointsDisplay, 4);
        mainPanel.add(menuPanel, BorderLayout.WEST);

        //add names to id the listeners
        questButton.setName("Quest");
        newQuestButton.setName("NewQuest");
        outfitButton.setName("Outfit");
        settingButton.setName("Setting");

        //add listeners to menu items
        addMenuListener(questButton);
        addMenuListener(newQuestButton);
        addMenuListener(outfitButton);
        addMenuListener(settingButton);

        //saves before exiting window
        frame.addWindowListener(new WindowAdapter()
        {
            @Override
            public void windowClosing(WindowEvent e)
            {
              settingsPanelClass.save();
              e.getWindow().dispose();
            }
        });

        
        panelList.add(questPanel);
        panelList.add(newQuestPanel);
        panelList.add(outfitPanel);
        panelList.add(settingsPanel);
        panelList.add(menuPanel);

        updateColours(QuestifyRun.defaultColours);

        //displays GUI
        this.paintComponents(getGraphics());
        displayCurrentCard();
        frame.add(mainPanel);
        frame.setMinimumSize(frame.getSize());
        frame.pack();
        frame.setMinimumSize(null);
        frame.setVisible(true);
    }

    private void menuGBC(JPanel panel, Component c, int y){
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weighty = 1;
        gbc.gridx = 0;
        gbc.gridy = y;
        panel.add(c,gbc);
    }

    public void displayCurrentCard(){
        CardLayout c = (CardLayout)(centerPanel.getLayout());
        switch(currentCard){
            case "1":
                c.show(centerPanel, currentCard); 
                break;
            case "2":
                c.show(centerPanel, currentCard); 
                System.out.println("choose");
                break;
            case "3":
                c.show(centerPanel, currentCard); 
                break;
            case "4":
                c.show(centerPanel, currentCard); 
                break;
            default:
                c.show(centerPanel, "1");
                break;
        }
    }

    public int setCurrentCard(int value){
        if (value > 0 && value < 5){
            currentCard = String.valueOf(value);
            displayCurrentCard();
            return 1;
        }
        return -1;
    }

    public String getCurrentCard(){
        return currentCard;
    }

    public JFrame getFrame(){
        return frame;
    } 

    public void addQuestGui(Quest q){
        questPanelClass.addQuest(q);
    }

    public List<Quest> getQuestList(){
        return questList;
    }

    public List<Color> getColourList(){
        colours.add(bg);
        colours.add(menuBg);
        colours.add(titleBg);
        colours.add(buttonBg);

        return colours;
    }
    

    public void hardReset(int cardNum){
        CardLayout c = (CardLayout)(centerPanel.getLayout());
        switch(cardNum){
            case 1:
                c.removeLayoutComponent(questPanel);
                questPanel = null;
                //sets up quest center piece
                questPanelClass = new QuestPanel(questList, this);
                questPanel = questPanelClass.getPanel();
                centerPanel.add("1", questPanel);
                break;
            case 2:
                c.removeLayoutComponent(newQuestPanel);
                newQuestPanel = null;
                //sets up newQuest center piece
                NewQuestPanel newQuestPanelClass = new NewQuestPanel(this);
                newQuestPanel = newQuestPanelClass.getPanel(); 
                centerPanel.add("2", newQuestPanel);
                break;
            case 3:
                c.removeLayoutComponent(outfitPanel);
                outfitPanel = null;
                //sets up outfit center 
                OutfitsPanel outfitPanelClass = new OutfitsPanel();
                outfitPanel = outfitPanelClass.getPanel(); 
                centerPanel.add("3", outfitPanel);
                break;
            case 4:
                c.removeLayoutComponent(settingsPanel);
                settingsPanel = null;
                //sets up settings center piece
                SettingsPanel settingsPanelClass = new SettingsPanel(this);
                settingsPanel = settingsPanelClass.getPanel();
                centerPanel.add("4", settingsPanel);
                break;
        }
    }


    public void addMenuListener(JButton button){
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                
                JButton o = (JButton)e.getSource();
                String name = o.getName();

                switch(name){
                    case "Quest":
                        currentCard = "1"; 
                        displayCurrentCard();
                        break;
                    case "NewQuest":
                        currentCard = "2";
                        displayCurrentCard(); 
                        System.out.println("cheese");
                        break;
                    case "Outfit":
                        currentCard = "3";
                        displayCurrentCard();
                        break;
                    case "Setting":
                        currentCard = "4";
                        displayCurrentCard();
                        break;
                }
            }
        });
    }

    public void addPoints(int pointsToBeAdded){
        this.points += pointsToBeAdded;
        updatePointsDisplay();
    }

    public void subPoints(int pointsToBeAdded){
        this.points -= pointsToBeAdded;
        updatePointsDisplay();
    }

    private void updatePointsDisplay(){
        pointsDisplay.setText(String.valueOf(points));
    }

    private void updateC(){
        for (JPanel itm : panelList){
            itm.setBackground(bg);
        }
        menuPanel.setBackground(menuBg);
        pointsDisplay.setBackground(titleBg);
        mainPanel.setBackground(titleBg);
    }

    public void updateColours(List<Color> c){
        bg = c.get(0);
        menuBg = c.get(1);
        titleBg = c.get(2);
        buttonBg = c.get(3);

        updateC();

        frame.revalidate();
        frame.repaint();
    }
}
