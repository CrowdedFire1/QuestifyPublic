package CardPanels;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class OutfitsPanel extends AbstractCardPanel{
    public OutfitsPanel(){
        panel = new JPanel();
    }
}
