package CardPanels;
import javax.crypto.AEADBadTagException;
import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import Gui.QuestGui;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractCardPanel extends JPanel {
    protected JPanel panel;
    protected JFrame frame;
    protected QuestGui questGui;
    protected int cardNum; 
    protected final Border BORDER = BorderFactory.createLineBorder(Color.black, 1);
    protected final Border GAP = BorderFactory.createEmptyBorder(10,10,10,10);
    protected final Border COMBINED = BorderFactory.createCompoundBorder(BORDER, GAP);
    protected List<Color> colorStore = new ArrayList<>();
    protected Color bg = new Color(241, 222, 198);
    protected Color menuBg = new Color(23, 155, 174);
    protected Color titleBg = new Color(255, 131, 67);
    protected Color buttonBg = new Color(65, 88, 166);

    public JPanel getPanel(){
        return panel;
    }

    public void changeColour(List<Color> c){
        bg = c.get(0);
        menuBg = c.get(1);
        titleBg = c.get(2);
        buttonBg = c.get(3);
    }
    
}
